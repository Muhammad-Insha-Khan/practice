import React from "react";

function Service() {
  return <h1>Hello Service Page!</h1>;
}

export default Service;
