import React from "react";

function About() {
  return <h1>Hello About Page!</h1>;
}

export default About;
